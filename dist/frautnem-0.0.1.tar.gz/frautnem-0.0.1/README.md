# frautnEM

A set of library functions to be used in courses of electromagnetism.